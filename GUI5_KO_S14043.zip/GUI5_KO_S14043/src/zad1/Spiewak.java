/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad1;

public abstract class Spiewak {

    private String nazwisko;
    private static int count = 0;
    private int id;

    public Spiewak(String nazwisko) {
        this.nazwisko = nazwisko;
        id = ++ count;
    }

    abstract String spiewaj();

    public static Spiewak najglosniej(Spiewak[] spiewaki){
        Spiewak tmp = null;
        int max = 0;
        for (Spiewak sp : spiewaki){
            String text = sp.spiewaj();
            int count = 0;
            text = text.toLowerCase();
            for (int i = 0; i < text.length(); i++) {
                if (!(text.substring(i,i+1).equals(sp.spiewaj().substring(i,i+1))))
                    count++;
            }
            if (count > max){
                max = count;
                tmp = sp;
            }
        }
        return tmp;
    }

    @Override
    public String toString() {
        return "(" + id +")" + " " + nazwisko + ": " + spiewaj();
    }
}