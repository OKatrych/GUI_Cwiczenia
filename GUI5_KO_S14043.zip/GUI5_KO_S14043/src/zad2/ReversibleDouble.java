package zad2;

public class ReversibleDouble implements Reversible {

    Double reverse;

    public ReversibleDouble(double toReverse) {
        this.reverse = toReverse;
    }

    @Override
    public Reversible reverse() {
        reverse = 1 / reverse;
        return null;
    }

    @Override
    public String toString() {
        return reverse.toString();
    }
}