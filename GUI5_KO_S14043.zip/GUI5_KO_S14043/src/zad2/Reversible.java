package zad2;

public interface Reversible {
    Reversible reverse();
}