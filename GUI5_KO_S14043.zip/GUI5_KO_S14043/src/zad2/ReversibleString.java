package zad2;

public class ReversibleString implements Reversible {

    private String reverse;

    public ReversibleString(String toReverse) {
        this.reverse = toReverse;
    }

    @Override
    public Reversible reverse() {
        String tmp = reverse;
        reverse = "";
        for (int i = tmp.length()-1; i >= 0 ; i--) {
            reverse += tmp.substring(i,i+1);
        }
        return null;
    }

    @Override
    public String toString() {
        return  reverse;
    }
}