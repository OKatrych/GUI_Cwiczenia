package zad2;


public abstract class Flowers {

    abstract String getName();

    abstract String getColor();

    abstract int getQuantity();

}
