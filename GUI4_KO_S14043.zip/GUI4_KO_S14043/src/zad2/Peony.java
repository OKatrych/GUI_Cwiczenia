package zad2;

public class Peony extends Flowers {
    String name = "piwonia";
    String color = "czerwony";
    int quantity;

    Peony(int quantity){
        this.quantity = quantity;
    }

    @Override
    String getName() {
        return name;
    }

    @Override
    String getColor() {
        return color;
    }

    @Override
    int getQuantity() {
        return quantity;
    }
}
