package zad2;

import java.util.HashMap;

public class PriceList {

    private static PriceList priceList = null;
    private static HashMap<String, Double> productsList;

    private PriceList(){
    }

    public static PriceList getInstance(){
        if (priceList == null){
            productsList  = new HashMap<>();
            priceList = new PriceList();
        }
        return priceList;
    }

    public void put(String nazwa, double cena){
        if (cena < 0)
            return;
        productsList.put(nazwa, cena);
    }

    public double getPrice(Flowers flower){
        if (productsList.containsKey(flower.getName()))
            return productsList.get(flower.getName());
        else
            return -1;
    }

    public boolean existItem(Flowers flower){
        return productsList.containsKey(flower.getName());
    }
}