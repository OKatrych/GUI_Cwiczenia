package zad2;

public class Rose extends Flowers{

    String name = "róża";
    String color = "czerwony";
    int quantity;

    Rose(int quantity){
        this.quantity = quantity;
    }

    @Override
    String getName() {
        return name;
    }

    @Override
    String getColor() {
        return color;
    }

    @Override
    int getQuantity() {
        return quantity;
    }
}