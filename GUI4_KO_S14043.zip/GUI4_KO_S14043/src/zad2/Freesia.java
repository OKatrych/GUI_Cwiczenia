package zad2;


public class Freesia extends Flowers {
    String name = "frezja";
    String color = "żółty";
    int quantity;

    Freesia(int quantity){
        this.quantity = quantity;
    }

    @Override
    String getName() {
        return name;
    }

    @Override
    String getColor() {
        return color;
    }

    @Override
    int getQuantity() {
        return quantity;
    }
}
