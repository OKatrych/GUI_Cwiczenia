package zad2;


import java.util.ArrayList;

public class Customer {

    private String imie;
    private double cash;
    private ShoppingCart shoppingCart;
    private PriceList priceList;

    public Customer(String imie, double cash) {
        if (cash < 0)
            this.cash = 0;
        else
            this.cash = cash;
        this.imie = imie;
        shoppingCart = new ShoppingCart(this);
        priceList = PriceList.getInstance();
    }

    public ShoppingCart getShoppingCart(){
        return this.shoppingCart;
    }

    public void pay(){
        ArrayList<Flowers> flowers = shoppingCart.getShoppingCardItems();
        for (Flowers flower : flowers){
            if (!(priceList.existItem(flower)))
                shoppingCart.remove(flower);
        }
        double sum = shoppingCart.getSum();
        while (sum > cash){
            shoppingCart.remove(shoppingCart.maxPrice());
            sum = shoppingCart.getSum();
        }
        cash -= sum;
    }

    public void pack(Box box){
        box.pack();
    }

    public void get(Flowers flower){
        shoppingCart.put(flower);
    }

    public String getImie() {
        return imie;
    }

    public double getCash() {
        return cash;
    }


}
