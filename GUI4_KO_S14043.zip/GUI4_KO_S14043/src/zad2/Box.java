package zad2;

import java.util.ArrayList;

public class Box extends ShoppingCart{
    private Customer wlasciciel;
    private ArrayList<Flowers> boxItems;
    private PriceList priceList;
    private ShoppingCart shoppingCart;

    public Box(Customer wlasciciel){
        super(wlasciciel);
        this.wlasciciel = wlasciciel;
        priceList = PriceList.getInstance();
        shoppingCart = wlasciciel.getShoppingCart();
    }

    public void pack(){
        boxItems = shoppingCart.getShoppingCardItems();
        shoppingCart.removeAllItems();
    }

    public double priceOf(String color){
        double sum = 0;
        for (Flowers flower : boxItems){
            if (flower.getColor().equals(color)){
                sum += flower.getQuantity() * priceList.getPrice(flower);
            }
        }
        return sum;
    }

    @Override
    public String toString() {
        if (boxItems.isEmpty())
            return "Pudełko własciciel " + wlasciciel.getImie() + " -- pusto";

        String result = "Pudełko własciciel " + wlasciciel.getImie() + "\n";
        for (Flowers flower : boxItems){
            result += flower.getName() + ", color: " + flower.getColor() + ", ilość "
                    + flower.getQuantity() +", cena "+ priceList.getPrice(flower)+"\n";
        }
        return result;
    }
}
