package zad2;


public class Lilac extends Flowers {

    String name = "bez";
    String color = "fioletowy";
    int quantity;

    Lilac(int quantity){
        this.quantity = quantity;
    }

    @Override
    String getName() {
        return name;
    }

    @Override
    String getColor() {
        return color;
    }

    @Override
    int getQuantity() {
        return quantity;
    }
}
