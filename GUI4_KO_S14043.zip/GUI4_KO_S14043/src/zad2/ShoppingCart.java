package zad2;

import java.util.ArrayList;

public class ShoppingCart {
    private ArrayList<Flowers> flowers ;
    private Customer wlasciciel;
    private PriceList priceList;


    public ShoppingCart(Customer wlasciciel) {
        flowers = new ArrayList<>();
        priceList = PriceList.getInstance();
        this.wlasciciel = wlasciciel;
    }

    public void put(Flowers flower){
        flowers.add(flower);
    }

    public void remove(Flowers flower){
        flowers.remove(flower);
    }

    public void removeAllItems(){
        flowers = null;
    }

    public ArrayList<Flowers> getShoppingCardItems(){
        return flowers;
    }

    public double getSum(){
        double sum = 0;
        for (Flowers flower : flowers){
            sum += flower.getQuantity() * priceList.getPrice(flower);
        }
        return sum;
    }

    public Flowers maxPrice(){
        double max = 0;
        Flowers maxFloverPrice = null;
        for (Flowers flower : flowers){
            double sum = flower.getQuantity() * priceList.getPrice(flower);
            if (max < sum){
                maxFloverPrice = flower;
                max = sum;
            }
        }
        return maxFloverPrice;
    }

    @Override
    public String toString() {
        if (flowers == null || flowers.isEmpty())
            return "Wózek własciciel " + wlasciciel.getImie() + " -- pusto";

        String result = "Wózek własciciel " + wlasciciel.getImie() + "\n";
        for (Flowers flower : flowers){
            result += flower.getName() + ", color: " +flower.getColor()+", ilość "
                    + flower.getQuantity() +", cena "+ priceList.getPrice(flower)+"\n";
        }
        return result;
    }
}
