/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad1;


public class Przedzial {

    private int pocz, koniec;

  public Przedzial(int a, int b) {
    if (a < b) {
        pocz = a;
        koniec = b;
    }else {
        pocz = b;
        koniec = a;
    }
  }

  Przedzial przeciecie(Przedzial p) {
      int pocz;
      int koniec;
      /**
       * Jeśli tylko jeden numer jest wspólny
       */
      if (this.pocz == p.koniec)
          return new Przedzial(this.pocz, this.pocz);
      else if (this.koniec == p.pocz)
          return new Przedzial(this.koniec, this.koniec);
      /**
       * Szukamy większy początek i koniec
       */
      if ((p.pocz > this.pocz) && (p.pocz < this.koniec))
          pocz = p.pocz;
      else if ((this.pocz > p.pocz) && (this.pocz < p.koniec))
          pocz = this.pocz;
      else
          return null;
      if ((p.koniec < this.koniec))
          koniec = p.koniec;
      else
          koniec = this.koniec;
      return new Przedzial(pocz,koniec);
  }

    public int poczatek() {
        return pocz;
    }

    public int koniec() {
        return koniec;
    }

    @Override
    public String toString() {
        return "["+ pocz + "," + koniec + "]";
    }
}
