/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad3;

import zad2.Employee;

public class Emps {
    Employee e;
    Emps prev, next;

    Emps(Employee e){
        this.e = e;
        next = null;
    }

    @Override
    public String toString() {
        return e.toString();
    }

    public void changeSalary(double salary) {
        e.chgSalary(salary);
    }
}
