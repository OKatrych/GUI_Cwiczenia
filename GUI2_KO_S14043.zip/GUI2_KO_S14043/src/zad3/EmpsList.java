/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad3;

import zad2.Employee;

public class EmpsList {
    private Emps first;

    public EmpsList(){
        first = null;
    }

    public void add(Employee e){
        if (first == null) {
            first = new Emps(e);
            first.prev = null;
        } else{
            Emps tmp = first;
            while(tmp.next != null){
                tmp = tmp.next;
            }
            tmp.next = new Emps(e);
            tmp.next.prev = tmp;
        }
    }

    public void changeAllSalaries(double salary){
        Emps tmp = first;
        while (tmp != null){
            tmp.changeSalary(salary);
            tmp = tmp.next;
        }
    }

    public void showForward(){
        Emps tmp = first;
        while (tmp != null){
            System.out.println(tmp);
            tmp = tmp.next;
        }
    }

    public void showBackward(){
        Emps tmp = first;
        while (tmp.next != null){
            tmp = tmp.next;
        }
        while (tmp != null){
            System.out.println(tmp);
            tmp = tmp.prev;
        }
    }
}