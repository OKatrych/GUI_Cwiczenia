/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad2;


import javax.swing.*;
import java.util.Scanner;

public class EmpManager {

    static Employee defEmp(String msg){
        String in = JOptionPane.showInputDialog(msg);
        try(Scanner sc = new Scanner(in)){
            return new Employee(sc.next(),sc.next(),sc.nextInt(),sc.nextDouble());
        }catch (Exception ex) {
            System.out.println("Błąd");
        }
        return null;
    }

    public static void showInfo(Employee e){
        JOptionPane.showMessageDialog(null, e.toString());
    }

    public static void changeSalary(Employee e){
        double procent = 0;
        try{
            procent = Double.parseDouble(JOptionPane.showInputDialog("O jaki procent zmienic pensje ?"));
        }catch (Exception ex){
            System.out.println("Bad procent");
        }
        e.chgSalary(procent);
    }
}    
