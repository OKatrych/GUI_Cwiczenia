/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad2;


public class Employee {

    private String firstName;
    private String lastName;
    private int age;
    private double salary;

    public Employee(String firstName, String lastName, int age, double salary) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.salary = salary;
    }

    public void chgSalary(double procent) {
        if (procent < -100)
            return;
        salary = salary + (salary * (procent / 100));
    }

    public void setSalary(double salary) {
        if (salary < 0)
            return;
        this.salary = salary;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return firstName + " " + lastName + " " + age + " " + salary;
    }
}
