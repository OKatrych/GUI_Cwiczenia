/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad3;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    public static void main(String[] args) {
        new mFrame();
    }
}

class mFrame extends JFrame {

    mFrame() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setButton(getContentPane());
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void setButton(Container pane){
        pane.setLayout(new BorderLayout());
        pane.add(initButton());
    }

    private JButton initButton(){
        JButton button = new JButton("Click");
        Color[] colors = {
                Color.cyan, Color.blue, Color.gray
        };
        button.addActionListener(new ActionListener() {
            int count = 0;
            @Override
            public void actionPerformed(ActionEvent e) {
                if (count == colors.length){
                    count = 0;
                }
                button.setBackground(colors[count++]);
                button.setOpaque(true);
            }
        });
        return button;
    }

}
