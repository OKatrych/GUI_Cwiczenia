package zad4;

class Strings {
    final static String title = "no title";

    final static String file = "File";
    final static String edit = "Edit";
    final static String options = "Options";
    final static String open = "Open";
    final static String save = "Save";
    final static String save_as  = "Save as ...";
    final static String exit  = "Exit";
    final static String addresses  = "Addresses";
    final static String work = "Work";
    final static String school = "School";
    final static String home = "Home";
    final static String foreground = "Foreground";
    final static String background = "Background";
    final static String font_size = "Font size";

    final static String blue = "Blue ";
    final static String yellow = "Yellow ";
    final static String orange = "Orange ";
    final static String red = "Red ";
    final static String white = "White ";
    final static String black = "Black ";
    final static String green = "Green ";

    static final String WORKaddress = "Work address";
    static final String HOMEaddress = "Home address";
    static final String SCHOOLaddress = "School address";
}
