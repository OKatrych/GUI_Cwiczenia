/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad4;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(Main::createAndShowGUI);
    }

    private static void createAndShowGUI(){
        JFrame frame = new JFrame("TextEditor");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        TextEditor editor = new TextEditor();
        frame.setJMenuBar(new MenuBar(frame, editor));
        frame.setContentPane(editor);

        //Display the window.
        frame.setSize(500, 400);
        frame.setVisible(true);
    }
}