package zad4;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.Reader;

class TextEditor extends JPanel{
    private JTextArea textArea;

    TextEditor() {
        createContentPane();
    }

    private void createContentPane(){
        setLayout(new BorderLayout());
        setOpaque(true);

        textArea = new JTextArea(5,30);

        //Add the text area to the content pane.
        add(new JScrollPane(textArea), BorderLayout.CENTER);
    }

    void read(Reader reader){
        try {
            textArea.read(reader, null);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    JTextArea getTextArea(){
        return  textArea;
    }


    void setTextSize(int size){
        int style = textArea.getFont().getStyle();
        textArea.setFont(new Font(Font.DIALOG, style, size));
    }
}
