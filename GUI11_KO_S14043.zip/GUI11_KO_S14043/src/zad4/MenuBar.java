package zad4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.*;

class MenuBar extends JMenuBar implements ActionListener {
    private Frame frame;
    private TextEditor editor;
    private JMenuItem open, save, saveAs, exit,
            work, school, home,
            blueF, yellowF, orangeF, redF, whiteF, blackF, greenF,
            blueB, yellowB, orangeB, redB, whiteB, blackB, greenB;
    private boolean opened;
    private File currentFile;


    MenuBar(JFrame frame, TextEditor editor){
        this.frame = frame;
        this.editor = editor;
        opened = false;
        currentFile = new File("./");
        createMenuBar();
        this.frame.setTitle(Strings.title);
    }

    private void createMenuBar(){
        JMenu file, addresses, edit,
                options, foreground, background, fontSize;

        file = new JMenu(Strings.file);
        options = new JMenu(Strings.options);
        edit = new JMenu(Strings.edit);
        addresses = new JMenu(Strings.addresses);
        foreground = new JMenu(Strings.foreground);
        background = new JMenu(Strings.background);
        fontSize = new JMenu(Strings.font_size);

        // creating "File" menu items
        file.add(open = new JMenuItem(Strings.open));
        open.setMnemonic(KeyEvent.VK_O);
        open.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK));

        file.add(save = new JMenuItem(Strings.save));
        save.setMnemonic(KeyEvent.VK_S);
        save.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));

        file.add(saveAs = new JMenuItem(Strings.save_as));
        saveAs.setMnemonic(KeyEvent.VK_A);
        saveAs.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_A, InputEvent.CTRL_DOWN_MASK));

        JSeparator separator;
        file.add(separator = new JSeparator());
        separator.setBorder(BorderFactory.createRaisedBevelBorder());
        separator.setPreferredSize(new Dimension(JSeparator.WIDTH, 4));
        separator.setBackground(Color.RED);

        file.add(exit = new JMenuItem(Strings.exit));
        exit.setMnemonic(KeyEvent.VK_Q);
        exit.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_X, InputEvent.CTRL_DOWN_MASK));

        // creating "Edit" menu items
        addresses.add(work = new JMenuItem(Strings.work));
        work.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_P, InputEvent.CTRL_DOWN_MASK + InputEvent.SHIFT_MASK
        ));
        addresses.add(school = new JMenuItem(Strings.school));
        school.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK + InputEvent.SHIFT_MASK
        ));
        addresses.add(home = new JMenuItem(Strings.home));
        home.setAccelerator(KeyStroke.getKeyStroke(
                KeyEvent.VK_D, InputEvent.CTRL_DOWN_MASK + InputEvent.SHIFT_MASK
        ));

        edit.add(addresses);

        // creating "Foreground" menu items
        foreground.add(blueF = new JMenuItem(Strings.blue, getIcon(Color.BLUE)));
        foreground.add(yellowF = new JMenuItem(Strings.yellow, getIcon(Color.YELLOW)));
        foreground.add(orangeF = new JMenuItem(Strings.orange, getIcon(Color.ORANGE)));
        foreground.add(redF = new JMenuItem(Strings.red, getIcon(Color.RED)));
        foreground.add(whiteF = new JMenuItem(Strings.white, getIcon(Color.WHITE)));
        foreground.add(blackF = new JMenuItem(Strings.black, getIcon(Color.BLACK)));
        foreground.add(greenF = new JMenuItem(Strings.green, getIcon(Color.GREEN)));
        options.add(foreground);

        // creating "Background" menu items
        background.add(blueB = new JMenuItem(Strings.blue, getIcon(Color.BLUE)));
        background.add(yellowB = new JMenuItem(Strings.yellow, getIcon(Color.YELLOW)));
        background.add(orangeB = new JMenuItem(Strings.orange, getIcon(Color.ORANGE)));
        background.add(redB = new JMenuItem(Strings.red, getIcon(Color.RED)));
        background.add(whiteB = new JMenuItem(Strings.white, getIcon(Color.WHITE)));
        background.add(blackB = new JMenuItem(Strings.black, getIcon(Color.BLACK)));
        background.add(greenB = new JMenuItem(Strings.green, getIcon(Color.GREEN)));
        options.add(background);

        //initButtons
        initButtons(open, save, saveAs, exit, work, school, home,
                blueF, yellowF, orangeF, redF, whiteF, blackF, greenF,
                blueB, yellowB, orangeB, redB, whiteB, blackB, greenB, addresses, foreground, background, fontSize);

        // creating "Font size" menu items
        String[] sizes = {"8 pts", "10 pts","12 pts", "14 pts", "16 pts", "18 pts", "20 pts", "22 pts", "24 pts"};
        for (int i = 0; i < 9; i++) {
            JMenuItem item = new JMenuItem(sizes[i]);
            item.addActionListener(this);
            item.setBorder(BorderFactory.createRaisedBevelBorder());
            fontSize.add(item);
        }
        options.add(fontSize);

        add(file);
        add(edit);
        add(options);
    }

    /**
     * Set actions to pressing menu items
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(open))
            openFile();
        if (e.getSource().equals(save))
            save();
        if (e.getSource().equals(saveAs))
            saveAs();
        if (e.getSource().equals(exit))
            exit();
        if (e.getSource().equals(work))
            editor.getTextArea().insert(Strings.WORKaddress, editor.getTextArea().getCaretPosition());
        if (e.getSource().equals(school))
            editor.getTextArea().insert(Strings.SCHOOLaddress, editor.getTextArea().getCaretPosition());
        if (e.getSource().equals(home))
            editor.getTextArea().insert(Strings.HOMEaddress, editor.getTextArea().getCaretPosition());
        if (e.getSource().equals(blueB))
            setBackgroundColor(Color.blue);
        if (e.getSource().equals(yellowB))
            setBackgroundColor(Color.yellow);
        if (e.getSource().equals(orangeB))
            setBackgroundColor(Color.orange);
        if (e.getSource().equals(redB))
            setBackgroundColor(Color.red);
        if (e.getSource().equals(whiteB))
            setBackgroundColor(Color.white);
        if (e.getSource().equals(blackB))
            setBackgroundColor(Color.black);
        if (e.getSource().equals(greenB))
            setBackgroundColor(Color.green);
        if (e.getSource().equals(blueF))
            setForegroundColor(Color.blue);
        if (e.getSource().equals(yellowF))
            setForegroundColor(Color.yellow);
        if (e.getSource().equals(orangeF))
            setForegroundColor(Color.orange);
        if (e.getSource().equals(redF))
            setForegroundColor(Color.red);
        if (e.getSource().equals(whiteF))
            setForegroundColor(Color.white);
        if (e.getSource().equals(blackF))
            setForegroundColor(Color.black);
        if (e.getSource().equals(greenF))
            setForegroundColor(Color.green);
        else {
            JMenuItem item = (JMenuItem) e.getSource();
            String name = item.getText();
            if (name.endsWith("pts")) {
                int size = Integer.parseInt(name.replaceAll(" pts", ""));
                setTextSize(size);
            }
        }
    }

    /**
     * Opens file (by chooser dialog)
     */
    private void openFile(){
        JFileChooser fileChooser = new JFileChooser(currentFile);
        fileChooser.showOpenDialog(frame);
        try {
            editor.read(new FileReader(fileChooser.getSelectedFile()));
            currentFile = fileChooser.getSelectedFile();
            frame.setTitle(currentFile.getName());
            opened = true;
        } catch (Exception e) {
            opened = false;
            System.out.println("File was not open  [openFile() metod]");
            //e.printStackTrace();
        }
    }

    /**
     * "Slower" saving file
     */
    private void saveAs(){
        BufferedWriter writer = null;
        JFileChooser save = new JFileChooser();
        save.showSaveDialog(frame);
        try {
            writer = new BufferedWriter(new FileWriter(save.getSelectedFile()));
            writer.write(editor.getTextArea().getText());
            if (!opened)
                currentFile = save.getSelectedFile();
            opened = true;
        } catch (Exception ex) {
            System.out.println("File wasn't save  [saveAs() metod]");
            //ex.printStackTrace();
        }finally {
            if (writer != null)
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
    }

    /**
     * "Quick" saving file
     */
    private void save(){
        BufferedWriter writer = null;
        if (currentFile != null && opened){
            try {
                writer = new BufferedWriter(new FileWriter(currentFile));
                writer.write(editor.getTextArea().getText());
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                if (writer != null)
                    try {
                        writer.close();
                    } catch (IOException e) {
                        System.out.println("File wasn't save  [save() metod]");
                        //e.printStackTrace();
                    }
            }
        }else {
            saveAs();
        }
    }

    private void setForegroundColor(Color color){
        editor.getTextArea().setForeground(color);
    }

    private void setBackgroundColor(Color color){
        editor.getTextArea().setBackground(color);
    }

    private void exit(){
        System.exit(0);
    }

    private void setTextSize(int size){
        editor.setTextSize(size);
    }

    private void initButtons(AbstractButton ... btns){
        for (AbstractButton btn : btns){
            if (btn.getClass().isInstance(new JMenuItem()))
                btn.addActionListener(this);
            btn.setBorder(BorderFactory.createRaisedBevelBorder());
        }
    }

    private Icon getIcon(Color color){
        return new Icon() {
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.translate(x,y);
                g2.setPaint(color);
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.fillOval( 0, 2, 10, 10 );
                g2.translate(-x,-y);
                g2.dispose();
            }

            @Override
            public int getIconWidth() {
                return 14;
            }

            @Override
            public int getIconHeight() {
                return 14;
            }
        };
    }
}