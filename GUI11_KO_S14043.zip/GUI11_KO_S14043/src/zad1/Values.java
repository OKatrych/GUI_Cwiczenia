package zad1;

import java.awt.*;

class Values {
    static String[] ALIGMENT = {
            BorderLayout.PAGE_START,
            BorderLayout.CENTER,
            BorderLayout.LINE_START,
            BorderLayout.PAGE_END,
            BorderLayout.LINE_END
    };

    static String[] TEXTS = {
            "Label One", "Label Two", "Label Three", "Label Four", "Label Five"
    };
    static Color[] COLORS = {
            Color.BLUE, Color.CYAN, Color.GREEN, Color.PINK, Color.ORANGE
    };
    static int[] SIZES = {
            5, 10, 15, 20, 25
    };
    static String[] TOOLTIPS = {
            "One", "Two", "Three", "Four", "Five"
    };
}
