/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad1;


import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        new mFrame();
    }
}

class mFrame extends JFrame{
    private ArrayList<JLabel> labels;

    mFrame(){
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLabels(getContentPane());
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void setLabels(Container pane){
        pane.setLayout(new BorderLayout());
        generateLabels();
        for (int i = 0; i < labels.size(); i++) {
            pane.add(labels.get(i), Values.ALIGMENT[i]);
        }
    }

    private void generateLabels(){
        labels = new ArrayList<>(5);
        JLabel label;
        Font font;
        Border border;
        String[] texts = Values.TEXTS;
        int[] sizes = Values.SIZES;
        Color[] colors = Values.COLORS;
        String[] toolTips = Values.TOOLTIPS;

        for (int i = 0; i < texts.length; i++) {
            font = new Font(Font.DIALOG, Font.BOLD, sizes[i]);
            border = BorderFactory.createLineBorder(colors[i], sizes[i]);
            label = new JLabel(texts[i], JLabel.CENTER);
            label.setBorder(border);
            label.setOpaque(true);
            label.setFont(font);
            label.setForeground(colors[i]);
            label.setBackground(i == texts.length/2 ? Color.RED : colors[colors.length - i - 1]);
            label.setToolTipText(toolTips[i]);
            labels.add(label);
        }
    }
}