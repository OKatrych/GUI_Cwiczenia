/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad2;

import javax.swing.*;
import java.awt.*;

/**
 *          Zadanie nie jest gotowe
 */



public class Main {
    public static void main(String[] args) {
        new mFrame();
    }
}
    class mFrame extends JFrame {

        mFrame(){
            setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            setGUI(getContentPane());
            pack();
            setLocationRelativeTo(null);
            setVisible(true);
        }

        private void setGUI(Container pane){
            pane.setLayout(new GridLayout(3,1));
            generateGUI(pane);
        }

        private void generateGUI(Container pane){
            JPanel topMainPanel = new JPanel(new BorderLayout());
            JPanel topLeftPanel = new JPanel(new GridLayout(1,1));
            JPanel topRightPanel = new JPanel(new GridLayout(1,1));
            topLeftPanel.add(new JButton("A1"));
            topLeftPanel.add(new JButton("A2"));
            topLeftPanel.add(new JButton("A3"));
            topRightPanel.add(new JButton("B1"));
            topRightPanel.add(new JButton("B2"));
            topRightPanel.add(new JButton("B3"));
            topMainPanel.add(topLeftPanel, BorderLayout.LINE_START);
            topMainPanel.add(topRightPanel, BorderLayout.LINE_END);
            pane.add(topMainPanel);

            JTextArea text = new JTextArea();
            pane.add(new JScrollPane(text));

            JPanel bottomMainPanel = new JPanel(new BorderLayout());
            bottomMainPanel.setSize(new Dimension(pane.getWidth(), 25));
            JPanel bottomLeftPanel = new JPanel(new GridLayout(3,3));
            JPanel bottomRightPanel = new JPanel(new SpringLayout());
            bottomMainPanel.add(bottomLeftPanel, BorderLayout.LINE_START);
            bottomMainPanel.add(bottomRightPanel, BorderLayout.LINE_END);
            pane.add(bottomMainPanel);

        }
    }