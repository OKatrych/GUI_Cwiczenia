/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad1;

public class Main {

    public static void main(String[] args){
        Work work = new Work("../Towary.txt");
        work.startWork();
    }
}