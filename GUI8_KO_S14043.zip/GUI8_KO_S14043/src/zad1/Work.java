/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad1;

import java.io.File;
import java.util.Scanner;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;


public class Work {
    private String fileDir;
    private BlockingQueue<Item> itemList;
    private volatile boolean flag;
    private volatile boolean scanned;

    public Work(String fileDir){
        this.fileDir = fileDir;
        flag = true;
        scanned = true;
        itemList = new ArrayBlockingQueue<>(200);
    }

    public void startWork(){
            startThreadA();
            startThreadB();
    }

    private void startThreadA(){

        Thread a = new Thread(() ->{
            int itemsCount = 0;
            int localCount = 0;
            Scanner sc = null;
            try {
                sc = new Scanner(new File(fileDir));
                while (sc.hasNext()){
                    while (!flag);
                    String item = sc.nextLine();
                    itemList.put(new Item(
                            item.substring(0, item.indexOf(" ")) ,
                            item.substring(item.indexOf(" ")+1 , item.length())));

                    itemsCount++;
                    if (++localCount == 200){
                        System.out.println("utworzono " + itemsCount + " obiektów");
                        localCount = 0;
                        flag = false;
                    }

                }
                scanned = false;
                sc.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        a.start();
    }

    private void startThreadB(){
        Thread b = new Thread(() ->{
            Item item;
            int localCount = 0;
            int flagCount= 0;
            int totalCount = 0;
            long totalWaga = 0;
            try {
                while (true) {
                    while (flag);
                    item = itemList.take();
                    totalWaga += Long.parseLong(item.getWeight());

                    totalCount++;
                    if (++localCount == 100) {
                        System.out.println("policzono wage " + totalCount + " towarów");
                        localCount = 0;
                    }
                    if (++flagCount == 200){
                        flagCount = 0;
                        flag = true;
                    }
                    if (!scanned && itemList.isEmpty())
                        break;
                }
                System.out.println(totalWaga);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        b.start();
    }
}