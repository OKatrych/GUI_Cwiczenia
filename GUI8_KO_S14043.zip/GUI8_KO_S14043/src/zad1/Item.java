/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad1;

public class Item {

    private final String id;
    private final String weight;

    public Item(String id, String weight) {
        this.id = id;
        this.weight = weight;
    }

    public String getWeight() {
        return weight;
    }
}
