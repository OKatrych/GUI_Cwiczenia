/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad2;


import java.util.concurrent.BlockingQueue;

public class Writer implements Runnable {
    private BlockingQueue<String> blockingQueue;
    private int size;

    public Writer(Author author){
        this.blockingQueue = author.getBlockingQueue();
        this.size = author.getSize();
    }

    @Override
    public void run() {
        try {
            for (int i = 0; i < size; i++) {
                System.out.println(blockingQueue.take());
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}