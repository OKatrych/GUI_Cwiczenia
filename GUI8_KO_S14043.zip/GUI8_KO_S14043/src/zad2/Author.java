/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad2;


import java.util.concurrent.BlockingQueue;
import java.util.concurrent.SynchronousQueue;

public class Author implements Runnable {

    private BlockingQueue<String> blockingQueue;
    private String[] args;

    public Author(String... args){
        blockingQueue = new SynchronousQueue<>();
        this.args = args;
    }

    @Override
    public void run() {
        for (String arg : args) {
            try {
                blockingQueue.put(arg);
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public BlockingQueue<String> getBlockingQueue() {
        return blockingQueue;
    }

    public int getSize(){
        return args.length;
    }

}
