package zad2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

class mFrame extends JFrame {

    mFrame(){
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        fillFrame(getContentPane());
        setActions();
        pack();
        setVisible(true);
    }

    private void fillFrame(Container box){
        box.setLayout(new BorderLayout());
        box.add(mList.list, BorderLayout.PAGE_START);
        box.add(mTextField.textField, BorderLayout.PAGE_END);
    }

    private void setActions(){
        JTextField field = mTextField.textField;
        JList<String> list = mList.list;
        DefaultListModel<String> model = mList.listModel;

        field.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getExtendedKeyCode() == KeyEvent.VK_ENTER) {
                    model.addElement(field.getText());
                    field.setText(null);
                }
            }
        });

        list.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getExtendedKeyCode() == KeyEvent.VK_ALT) {
                    if (list.getAnchorSelectionIndex() != -1)
                        model.remove(list.getAnchorSelectionIndex());
                }
            }
        });
    }
}