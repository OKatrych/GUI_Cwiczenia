package zad2;

import javax.swing.*;
import java.awt.*;

class mList {
    static JList<String> list;
    static DefaultListModel<String> listModel;

    static {
        listModel = new DefaultListModel<>();
        list = new JList<>(listModel);
        list.setPreferredSize(new Dimension(200, 300));
    }
}
