package zad2;

import javax.swing.*;

class mTextField {
    public static JTextField textField;

    static {
        textField = new JTextField("text");
    }

}
