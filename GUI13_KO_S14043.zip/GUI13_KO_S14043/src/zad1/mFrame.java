package zad1;

import javax.swing.*;
import java.awt.*;

public class mFrame extends JFrame {

    mFrame(){
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        getContentPane().add(new JScrollPane(new mList().getList()));
        setPreferredSize(new Dimension(300, 500));
        pack();
        setVisible(true);
    }
}
