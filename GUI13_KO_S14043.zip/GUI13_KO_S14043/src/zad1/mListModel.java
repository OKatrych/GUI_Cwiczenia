package zad1;

import javax.swing.*;
import java.util.Scanner;

class mListModel extends AbstractListModel{
    private String res = "";

    mListModel(){
        for (double c = -70, f = 94; c < 61; c++, f = ((9 * c)/5 + 32 )) {
            res += c + " stopni C = " + f +" stopni F \n";
        }
    }

    @Override
    public int getSize() {
        return 131;
    }

    @Override
    public Object getElementAt(int index) {
        Scanner sc = new Scanner(res);
        String text = "";
        for (int i = 0; i <= index; i++) {
            if (i == index){
                text = sc.nextLine();
            }else {
                sc.nextLine();
            }
        }
        sc.close();
        return text;
    }
}
