package zad1;

import javax.swing.*;

class mList {
    private JList list;
    mList(){
        createList();
    }

    private void createList(){
        list = new JList(new mListModel());
    }

    JList getList(){
        return list;
    }
}
