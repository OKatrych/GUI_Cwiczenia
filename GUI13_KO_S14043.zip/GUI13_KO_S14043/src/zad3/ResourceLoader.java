package zad3;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Plik musi być *.txt
 *
 * Zakładam, że informacja w pliku jest następująca :
 *
 *  NAZWA_KSIĄŻKI
 *  AUTOR
 *  CENA
 *  NAZWA_PLIKU_OBRAZKA
 *  ---
 *
 *  Naprzykład :
 *
 *  Dwadzieścia tysięcy mil podmorskiej żeglugi
 *  Juliusz Verne
 *  200
 *  Nemo.jpg
 *  ---
 *  Mistrz i Małgorzata
 *  Michaił Bułhakow
 *  Woland.png
 *  ---
 */


class ResourceLoader {
    private ArrayList<Book> books;

    ResourceLoader(){
        books = new ArrayList<>();
    }

    void loadInfo(File file){
        Scanner sc = null;
        try {
            sc = new Scanner(file);
            while (sc.hasNext()){
                String name = sc.nextLine();
                String author = sc.nextLine();
                String price = sc.nextLine();
                String imagePath = file.getPath().substring(0, file.getPath().lastIndexOf("/")+1) + sc.nextLine();
                BufferedImage image = ImageIO.read(new File(imagePath));
                sc.nextLine();

                books.add(new Book(name, author, price, image));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (sc != null)
                sc.close();
        }
    }

    ArrayList<Book> getBooks() {
        return books;
    }

}
