package zad3;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.ArrayList;

class mFrame extends JFrame{

    private DefaultTableModel model;
    private JTable table;

    mFrame(){
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        fillFrame();
        setPreferredSize(new Dimension(1000, 500));
        pack();
        setVisible(true);
    }

    private void fillFrame(){
        ArrayList<Book> books = loadBooks();
        String[] columnNames = {"Name", "Author", "Price", "Image"};
        Object[][] data = new Object[books.size()][4];
        for (int i = 0; i < data.length; i++) {
                data[i] = parseBookInfo(books.get(i));
        }
        model = new DefaultTableModel(data, columnNames){
            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return columnIndex == 2;
            }
        };
        table = new JTable(model) {
            //  Returning the Class of each column will allow different
            //  renders to be used based on Class
            public Class getColumnClass(int column) {
                return getValueAt(0, column).getClass();
            }
        };
        table.setRowHeight(200);

        for (int i = 0; i < books.size(); i++) {
            table.setRowHeight(i, books.get(i).icon.getIconHeight());
        }

        setLayout(new BorderLayout());
        add(new JScrollPane(table), BorderLayout.CENTER);
        table.setFillsViewportHeight(true);
        JPanel bottomPanel = new JPanel(new BorderLayout());
        JButton add = new JButton("Add");
        JButton del = new JButton("Delete");
        addListeners(add, del);
        bottomPanel.add(add, BorderLayout.LINE_START);
        bottomPanel.add(del, BorderLayout.LINE_END);
        add(bottomPanel, BorderLayout.PAGE_END);
    }

    private void addListeners(JButton add, JButton del){
        add.addActionListener((ActionEvent e) -> model.addRow(new Object[]{"","","",""}));
        del.addActionListener((ActionEvent e) -> {
            if (model.getRowCount() != 0) {
                if (table.getSelectedRow() != -1)
                    model.removeRow(table.getSelectedRow());
                else
                    model.removeRow(model.getRowCount() - 1);
            }
        });
    }

    private ArrayList<Book> loadBooks(){
        ResourceLoader loader = new ResourceLoader();
        JFileChooser chooser = new JFileChooser();
        chooser.showOpenDialog(this);
        if (chooser.getSelectedFile() != null && chooser.getSelectedFile().getName().endsWith("txt"))
            loader.loadInfo(chooser.getSelectedFile());
        return loader.getBooks();
    }

    private Object[] parseBookInfo(Book book){
        return new Object[]{book.name, book.author, book.price, book.icon};
    }


}
