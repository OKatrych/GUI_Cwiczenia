package zad3;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

class Book {

    String name;
    String author;
    String price;
    Icon icon;

    Book(String name, String author, String  price, BufferedImage icon) {
        this.name = name;
        this.author = author;
        this.price = price;
        this.icon = new ImageIcon(icon.getScaledInstance(150, 200, Image.SCALE_SMOOTH));
    }
}
