/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad1;


import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

  public static void main(String[] args) {
    String fname = System.getProperty("user.home") + "/tab.txt";
    int arr[] = scanFile(fname);
    System.out.println(getMax(arr));
  }

  private static int[] scanFile(String fname){
    int arr[] = null;
    ArrayList<Integer> numbers = new ArrayList<>();
    try(Scanner sc = new Scanner(new File(fname))) {
      while (sc.hasNext()){
        if (sc.hasNextInt())
           numbers.add(sc.nextInt());
        else
          throw new Exception();
      }
      arr = new int[numbers.size()];
      for (int i = 0; i < arr.length; i++) {
        arr[i] = numbers.get(i);
      }
    }catch (Exception ex){
      System.out.println("***");
    }
    return arr;
  }

  private static String getMax(int[] arr){
    if (arr == null)
      return "";
    String result = "";
    ArrayList<Integer> maxIndexes = new ArrayList<>();
    int max = arr[0];
    for (int i = 0; i < arr.length; i++) {
      if (arr[i] > max){
        max = arr[i];
        maxIndexes.clear();
        maxIndexes.add(i);
      }else if (arr[i] == max){
        maxIndexes.add(i);
      }
      result += (arr[i] +" ");
    }
    result += ("\n" + max + "\n");
    for (int x : maxIndexes) {
      result += (x + " ");
    }
    return result;
  }
}