/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad2;

import java.io.FileReader;
import java.io.StreamTokenizer;
import java.util.*;

public class CountWords {
    private Map<String, Integer> result;

    public CountWords(String fname){
        scanFile(fname);
    }

    private void scanFile(String fname){
        StreamTokenizer st;
        try {
            st = new StreamTokenizer(new FileReader(fname));
            result = new LinkedHashMap<>();
            while(st.nextToken() != StreamTokenizer.TT_EOF){
                if (st.ttype == StreamTokenizer.TT_WORD){
                    String word = st.sval;
                    if (result.containsKey(word)){
                        int tmp = result.get(word);
                        result.replace(word, tmp, ++tmp);
                    }else {
                        result.put(word, 1);
                    }
                }
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public List<String> getResult(){
        List<String> list = new LinkedList<>();
        for (HashMap.Entry word : result.entrySet()) {
            list.add(word.getKey()+ " " + word.getValue());
        }
        return list;
    }
}