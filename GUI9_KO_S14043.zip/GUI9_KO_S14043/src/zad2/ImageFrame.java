package zad2;

import javax.swing.*;

public class ImageFrame extends JFrame {

    ImageFrame(String[] args) {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        add(new mImagePanel(args, this));
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

}
