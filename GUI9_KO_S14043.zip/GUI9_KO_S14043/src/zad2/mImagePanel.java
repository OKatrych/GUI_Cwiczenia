package zad2;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;

public class mImagePanel extends JPanel{
    private ArrayList<Image> images;
    private ImageFrame imageFrame;
    private Image currentImage;
    private Thread thread;
    private boolean loaded;
    private int time;
    private int textSize;

    mImagePanel(String[] args, ImageFrame frame) {
        time = Integer.parseInt(args[1] +"000");
        textSize = Integer.parseInt(args[2]);
        imageFrame = frame;
        loadImages(args[0]);
        setCurrentImage();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (loaded) {
            g.drawImage(currentImage, 0, 0, getWidth(), getHeight(), this);
            if (!thread.isAlive()) {
                drawCenteredString(g, "Koniec prezentacji");
            }
        }else {
            drawCenteredString(g, "Brak obrazka");
        }
    }

    private void setCurrentImage(){
        thread = new Thread(() -> {
            int size = images.size();
            for (int i = 0; i < size; i++) {
                setImage();
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            currentImage = null;
            repaint();
        });
        thread.start();
    }

    private void setImage(){
        currentImage = images.get(0);
        images.remove(0);
        setPreferredSize(new Dimension(currentImage.getWidth(this), currentImage.getHeight(this)));
        imageFrame.setSize(currentImage.getWidth(this), currentImage.getHeight(this));
        repaint();
    }

    private void drawCenteredString(Graphics g, String s){
        g.setFont(new Font("mFont", Font.BOLD, textSize));
        int x = (getWidth() - g.getFontMetrics().stringWidth(s)) / 2;
        int y = (g.getFontMetrics().getAscent()
                + (getHeight() - (g.getFontMetrics().getAscent() + g.getFontMetrics().getDescent()))
                / 2);
        g.drawString(s, x, y);
    }

    private ArrayList<Image> loadImages(String path){
        images = new ArrayList<>();
        try {
            File directory = new File(path);
            final String[] EXTENSIONS = new String[]{"gif", "png", "jpg"};

            FilenameFilter filter = (File dir, String name) -> {
                for (String ext : EXTENSIONS) {
                    if (name.endsWith("." + ext)) {
                        return true;
                    }
                }
                return false;
            };
            for (File file : directory.listFiles(filter)) {
                images.add(ImageIO.read(file));
            }
            loaded = !images.isEmpty();
            if (!loaded)
                setPreferredSize(new Dimension(600,600));
        }catch (Exception ex){
            loaded = !images.isEmpty();
            setPreferredSize(new Dimension(600,600));
            return images;
        }
        return images;
    }
}