package zad1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;

class Calc {
    private JTextField[] column1, column2, column3, column4, column5;
    private JTextField[][] allColumns;
    private Color bg;
    private JLabel resField;
    private JButton calcBtn;
    private JCheckBox option1, option2;
    private boolean checked1 = false, checked2 = false;

    Calc (JTextField [][] fields, JLabel resField, JButton calc, JCheckBox option1, JCheckBox option2){
        parseColumns(fields);
        this.allColumns = fields;
        this.resField = resField;
        this.option1 = option1;
        this.option2 = option2;
        calcBtn = calc;
        setActions();
        setVerify();
        setFocusCalc();
    }

    //podatek
    private void calcTax(){
        Double tax = (0.15 * Double.parseDouble(column4[3].getText())) -
                Double.parseDouble(column5[3].getText());
        resField.setText(tax.toString());
    }

    //dochód
    private void calcEarnings(int row){
        if (row == -1){
            for (int i = 0; i < 3; i++) {
                if ((!column1[i].getText().isEmpty())) {
                    Double res = Double.parseDouble(column1[i].getText()) -
                            (column3[i].getText().isEmpty() ? 0.0 : Double.parseDouble(column3[i].getText()));
                    column4[i].setText(res.toString());
                }else {
                    column4[i].setText("0.0");
                }
            }
        }else{
            if ((!column1[row].getText().isEmpty())) {
                Double res = Double.parseDouble(column1[row].getText()) -
                        (column3[row].getText().isEmpty() ? 0.0 : Double.parseDouble(column3[row].getText()));
                column4[row].setText(res.toString());
            }else {
                column4[row].setText("0.0");
            }
        }
    }

    //koszty uzyskania przychodu
    private void calcObtainings(int row){
        if (row == -1){
            for (int i = 0; i < 3; i++) {
                if ((!column1[i].getText().isEmpty() && !column2[i].getText().isEmpty())) {
                Double res = Double.parseDouble(column1[i].getText()) * (Double.parseDouble(column2[i].getText()) / 100);
                column3[i].setText(res.toString());
                }else {
                    column3[i].setText("0.0");
                }
            }
        }else {
                if ((!column1[row].getText().isEmpty() && !column2[row].getText().isEmpty())) {
                    Double res = Double.parseDouble(column1[row].getText()) * (Double.parseDouble(column2[row].getText()) / 100);
                    column3[row].setText(res.toString());
                }else {
                    column3[row].setText("0.0");
                }
        }
    }

    private void calcALL(int row){
        calcObtainings(row);
        calcEarnings(row);
        calcSum(-1);
        if (row == -1)
            calcTax();
    }

    private void calcSum(int column){
        Double sum = 0.0;
        switch (column){
            case 1 :
                for (int i = 0; i < 3; i++) {
                    sum += column1[i].getText().isEmpty() ? 0.0 : Double.parseDouble(column1[i].getText());
                }
                column1[3].setText(sum.toString());
                break;
            case 3 :
                for (int i = 0; i < 3; i++) {
                    sum += column3[i].getText().isEmpty() ? 0.0 : Double.parseDouble(column3[i].getText());
                }
                column3[3].setText(sum.toString());
                break;
            case 4 :
                for (int i = 0; i < 3; i++) {
                    sum += column4[i].getText().isEmpty() ? 0.0 : Double.parseDouble(column4[i].getText());
                }
                column4[3].setText(sum.toString());
                break;
            case 5 :
                for (int i = 0; i < 3; i++) {
                    sum += column5[i].getText().isEmpty() ? 0.0 : Double.parseDouble(column5[i].getText());
                }
                column5[3].setText(sum.toString());
                break;
            case -1 :
                calcSum(1);
                calcSum(3);
                calcSum(4);
                calcSum(5);
                break;
        }
    }

    private void setVerify(){
        for (int i = 0; i < 3; i++) {
            InputVerifier verifier = new InputVerifier() {
                @Override
                public boolean verify(JComponent input) {
                    JTextField field = (JTextField) input;
                    try{
                        if (!field.getText().isEmpty())
                            Double.parseDouble(field.getText());
                        //field is normal
                        calcBtn.setEnabled(true);
                        field.setBackground(bg);
                        return true;
                    }catch (Exception ex){
                        System.out.println("verify error");
                        calcBtn.setEnabled(false);
                        field.setBackground(Color.YELLOW);
                        return false;
                    }
                }
            };
            column1[i].setInputVerifier(verifier);
            column2[i].setInputVerifier(verifier);
            column3[i].setInputVerifier(verifier);
            column5[i].setInputVerifier(verifier);
        }
    }

    private void setActions(){
        calcBtn.addActionListener((ActionEvent)-> calcALL(-1));
        option1.addItemListener((ItemEvent e)->checked1 = !checked1);
        option2.addItemListener((ItemEvent e)->checked2 = !checked2);
    }

    private void setFocusCalc(){
        for (int i = 0; i < 3; i++) {
            int j = i;
            column3[i].addFocusListener(new FocusListener() {
                @Override
                public void focusGained(FocusEvent e) {
                    calcObtainings(j);
                    calcSum(3);
                }
                @Override
                public void focusLost(FocusEvent e) {}
            });
            column4[i].addFocusListener(new FocusListener() {
                @Override
                public void focusGained(FocusEvent e) {
                    if ((!column1[j].getText().isEmpty())) {
                        if (!column3[j].getText().isEmpty()) {
                            calcEarnings(j);
                            calcSum(4);
                        }else {
                            if (!column2[j].getText().isEmpty()) {
                                calcObtainings(j);
                                calcEarnings(j);
                                calcSum(4);
                            }
                        }
                    }
                }
                @Override
                public void focusLost(FocusEvent e) {}
            });
        }
        for (JTextField[] allColumn : allColumns) {
            for (int j = 0; j < allColumn.length; j++) {
                int jLoc = j;
                allColumn[j].addFocusListener(new FocusListener() {
                    @Override
                    public void focusGained(FocusEvent e) {
                    }

                    @Override
                    public void focusLost(FocusEvent e) {
                        if (checked1)
                            calcALL(jLoc);
                        if (checked2)
                            calcALL(-1);
                    }
                });
            }
        }
    }

    private void parseColumns(JTextField[][] fields){
        column1 = new JTextField[4];
        column2 = new JTextField[3];
        column3 = new JTextField[4];
        column4 = new JTextField[4];
        column5 = new JTextField[4];

        for (int i = 0; i < fields.length; i++) {
            for (int j = 0; j < fields[i].length; j++) {
                switch (i) {
                    case 0 :
                        column1[j] = fields[i][j];
                        bg = column1[0].getBackground();
                        break;
                    case 1 :
                        if (j != 3)
                            column2[j] = fields[i][j];
                        break;
                    case 2 :
                        column3[j] = fields[i][j];
                        break;
                    case 3 :
                        column4[j] = fields[i][j];
                        break;
                    case 4 :
                        column5[j] = fields[i][j];
                        break;
                }
            }
        }
    }
}