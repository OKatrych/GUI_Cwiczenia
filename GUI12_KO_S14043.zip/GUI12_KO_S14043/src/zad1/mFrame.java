package zad1;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;

class mFrame extends JFrame {
    private JLabel bottomMainPanelText = new JLabel();
    private JTextField [][] allFields;
    private Color bd;
    private JLabel resLabel;
    private JButton calcBtn;
    private JCheckBox option1, option2;

    mFrame(){
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //set default background
        bd = getContentPane().getBackground();
        //Set up the content pane.
        addComponentsToPane(getContentPane());
        new Calc(allFields, resLabel, calcBtn, option1, option2);
        //Display the window.
        pack();
        setVisible(true);
    }

    private void addComponentsToPane(final Container pane){
        pane.add(getTopMainPanel(), "North");
        pane.add(getCenterMainPanel(), "Center");
        pane.add(getBottomMainPanel(), "South");
    }

    private JPanel getTopMainPanel(){
        JPanel panel = new JPanel(new FlowLayout());
        String[] labels = {"<html><center><b>Przychód</b></center></html>",
                           "<html><center><b>Koszty<br>uzyskania<br>w<br>%</b></center></html>",
                           "<html><center><b>Koszty<br>uzyskania<br>przychodu</b></center></html>",
                           "<html><center><b>Dochód</b></center></html>",
                           "<html><center><b>Zaliczki</b></center></html>"};
        JTextField [][] fields = getFields();
        allFields = fields;

        for (int i = 0; i < 5; i++) {
            panel.add(getBox(labels[i], fields[i]));
        }

        panel.setBorder(BorderFactory.createRaisedBevelBorder());
        return panel;
    }

    private JPanel getCenterMainPanel(){
        JPanel panel = new JPanel(new FlowLayout());
        calcBtn = new JButton("Oblicz");
        JPanel resPanel = new JPanel(new BorderLayout());
        resLabel = new JLabel("");
        JPanel trigersPanel = new JPanel(new FlowLayout());
        option1 = new JCheckBox("wiersza");
        option2 = new JCheckBox("podatku");
        JButton clearAll = new JButton("Wymaż");

        panel.add(calcBtn);
        resPanel.setBorder(BorderFactory.createLineBorder(Color.red, 2));
        resPanel.setBackground(Color.yellow);
        resLabel.setPreferredSize(new Dimension(180, 50));
        resLabel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.red), "Wyliczony Podatek"));
        resPanel.add(resLabel, BorderLayout.CENTER);
        panel.add(resPanel);

        trigersPanel.add(option1);
        trigersPanel.add(option2);
        trigersPanel.setPreferredSize(new Dimension(200, 50));
        trigersPanel.setBorder(BorderFactory.createTitledBorder("Automatyczne przeliczenia"));
        panel.add(trigersPanel);

        panel.setBorder(BorderFactory.createLoweredBevelBorder());

        clearAll.addActionListener((ActionEvent e) -> {
            for (JTextField [] fields : allFields)
                for (JTextField field : fields)
                    field.setText("");
        });
        panel.add(clearAll);

        return panel;
    }

    private JPanel getBottomMainPanel(){
        JPanel panel = new JPanel(new BorderLayout());
        panel.setPreferredSize(new Dimension(panel.getWidth(), 30));
        panel.setBorder(BorderFactory.createRaisedBevelBorder());
        panel.add(bottomMainPanelText, BorderLayout.LINE_START);
        return panel;
    }

    private JPanel getBox(String text, JTextField [] fields){
        JPanel box = new JPanel(new BorderLayout());
        JPanel child1 = new JPanel(new BorderLayout());
        JPanel child2 = new JPanel(new GridLayout(4,1));

        box.setPreferredSize(new Dimension(140, 185));
        box.setBorder(BorderFactory.createLineBorder(Color.BLUE));

        child1.add(new JLabel(text, JLabel.CENTER), BorderLayout.CENTER);
        child1.setPreferredSize(new Dimension(box.getWidth(), 80));
        child2.setPreferredSize(new Dimension(box.getWidth(), 105));

        for (JTextField field : fields) {
            child2.add(field);
        }

        box.add(child1, BorderLayout.PAGE_START);
        box.add(child2, BorderLayout.PAGE_END);
        return box;
    }

    private JTextField[][] getFields(){
        JTextField [][] fieldsBox = new JTextField[5][];
        for (int i = 0; i < fieldsBox.length; i++) {
            fieldsBox[i] = generateFields(i);
        }
        return fieldsBox;
    }

    private JTextField[] generateFields(int boxNumber){
        JTextField [] fields = new JTextField[4];
        JTextField field1 = new JTextField();
        JTextField field2 = new JTextField();
        JTextField field3 = new JTextField();
        JTextField field4 = new JTextField();
        field4.setEditable(false);

        fields[0] = field1;
        fields[1] = field2;
        fields[2] = field3;
        fields[3] = field4;

        switch (boxNumber){
            case 0 :
                setFieldAction(field1, "Przychód ze żródła: Żródło 1", Color.red);
                setFieldAction(field2, "Przychód ze żródła: Żródło 2", Color.red);
                setFieldAction(field3, "Przychód ze żródła: Żródło 3", Color.red);
                setFieldAction(field4, "Przychód ze żródła: Suma ze wszystkich żródeł", Color.blue);
                field4.setBackground(bd);
                field4.setForeground(Color.BLUE);
                break;
            case 1 :
                setFieldAction(field1, "Koszty uzyskania w % ze żródła: Żródło 1", Color.red);
                setFieldAction(field2, "Koszty uzyskania w % ze żródła: Żródło 2", Color.red);
                setFieldAction(field3, "Koszty uzyskania w % ze żródła: Żródło 3", Color.red);
                field4.setBackground(Color.LIGHT_GRAY);
                field4.setEnabled(false);
                break;
            case 2 :
                setFieldAction(field1, "Koszty uzyskania przychodu ze żródła: Żródło 1", Color.red);
                setFieldAction(field2, "Koszty uzyskania przychodu ze żródła: Żródło 2", Color.red);
                setFieldAction(field3, "Koszty uzyskania przychodu ze żródła: Żródło 3", Color.red);
                setFieldAction(field4, "Koszty uzyskania przychodu ze żródła: Suma ze wszystkich żródeł", Color.blue);
                field4.setBackground(bd);
                field4.setForeground(Color.BLUE);
                break;
            case 3 :
                setFieldAction(field1, "Dochód ze żródła: Żródło 1", Color.BLUE);
                setFieldAction(field2, "Dochód ze żródła: Żródło 2", Color.BLUE);
                setFieldAction(field3, "Dochód ze żródła: Żródło 3", Color.BLUE);
                setFieldAction(field4, "Dochód ze żródła: Suma ze wszystkich żródeł", Color.blue);
                field1.setEditable(false);
                field1.setBackground(bd);
                field1.setForeground(Color.BLUE);
                field2.setEditable(false);
                field2.setBackground(bd);
                field2.setForeground(Color.BLUE);
                field3.setEditable(false);
                field3.setBackground(bd);
                field3.setForeground(Color.BLUE);
                field4.setBackground(bd);
                field4.setForeground(Color.BLUE);
                break;
            case 4 :
                setFieldAction(field1, "Zaliczki ze żródła: Żródło 1", Color.red);
                setFieldAction(field2, "Zaliczki ze żródła: Żródło 2", Color.red);
                setFieldAction(field3, "Zaliczki ze żródła: Żródło 3", Color.red);
                setFieldAction(field4, "Zaliczki ze żródła: Suma ze wszystkich żródeł", Color.blue);
                field4.setBackground(bd);
                field4.setForeground(Color.BLUE);
                break;
        }
        return fields;
    }

    private void setFieldAction(JTextField field, String specialText, Color color){
        Border border = field.getBorder();
        field.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createLineBorder(color));
                bottomMainPanelText.setText(specialText);
            }

            @Override
            public void focusLost(FocusEvent e) {
                field.setBorder(border);
            }
        });
    }
}