/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad2;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Finder {
    Pattern pattern;
    Matcher matcher;
    String file;


    Finder(String fname){
        file = getFile(fname);
    }

    private String getFile(String fname){
        String result = "";
        String s;
        try(BufferedReader br = new BufferedReader(new FileReader(fname))){
           while ((s = br.readLine()) != null)
               result += s;
        }catch (IOException ex){
            ex.printStackTrace();
        }
        return result;
    }

    public int getIfCount() {
        int ifCount = 0;
        String regex = "if(\\s*?)\\((.*?)\\)";
        String tmp = file;
        tmp = tmp.replaceAll("(?:/\\*(?:[^*]|(?:\\*+[^*/]))*\\*+/)"," ");
        tmp = tmp.replaceAll("(//)(.*?)if(\\s*?)\\((.*?)\\)"," ");
        tmp = tmp.replaceAll("\".*?\""," ");
        pattern = Pattern.compile(regex);
        matcher = pattern.matcher(tmp);

        while (matcher.find()){
            ifCount++;
        }
        return ifCount;
    }

    public int getStringCount(String text) {
        int stringCount = 0;
        pattern = Pattern.compile(text);
        matcher = pattern.matcher(file);

        while (matcher.find()){
            stringCount++;
        }
        return stringCount;
    }
}