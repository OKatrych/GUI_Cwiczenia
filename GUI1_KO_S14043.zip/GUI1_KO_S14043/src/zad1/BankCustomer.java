package zad1;

public class BankCustomer {

    private Account account;
    private Person person;

    BankCustomer(Person person){
        this.account = new Account();
        this.person = person;
    }

    public Account getAccount(){
        return this.account;
    }

    @Override
    public String toString() {
        return person.getName() + " stan konta " + account.getBalance();
    }
}
