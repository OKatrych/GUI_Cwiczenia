package zad1;


public class Account {
    private double balance;
    static double interestRate;

    Account(){
        balance = 0;
    }

    public void deposit(double sum){
        if (sum <= 0)
            System.out.println("Operacja nedopuszczlna");
        else
            this.balance += sum;
    }

    public void withdraw(double sum){
        if (balance - sum < 0)
            System.out.println("Malo srodkow na koncie");
        else
            this.balance -= sum;
    }

    public void transfer(Account to , double sum){
        if (sum<=0 || sum > balance) {
            System.out.println("Operacja nedopuszczlna");
        } else {
            withdraw(sum);
            to.deposit(sum);
        }
    }

    public void addInterest(){
        this.balance = ((Account.interestRate / 100) * balance) + balance;
    }

    public static void setInterestRate(double interestRate){
        Account.interestRate = interestRate;
    }

    public double getBalance() {
        return balance;
    }
}
