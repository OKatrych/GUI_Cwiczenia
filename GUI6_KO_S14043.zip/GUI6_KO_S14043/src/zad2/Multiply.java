package zad2;

import java.math.BigDecimal;

public class Multiply extends Znak {
    @Override
    public String robic(BigDecimal x, BigDecimal y) {
        return x.multiply(y).toString();
    }
}
