package zad2;

import java.math.BigDecimal;

public abstract class Znak {
    public abstract String robic(BigDecimal x, BigDecimal y);
}