package zad2;

import java.math.BigDecimal;

public class Plus extends Znak {
    @Override
    public String robic(BigDecimal x, BigDecimal y) {
        return x.add(y).toString();
    }
}
