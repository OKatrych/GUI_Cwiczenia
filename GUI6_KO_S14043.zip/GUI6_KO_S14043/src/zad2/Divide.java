package zad2;

import java.math.BigDecimal;

public class Divide extends Znak{

    @Override
    public String robic(BigDecimal x, BigDecimal y) {
        return x.divide(y, 7, BigDecimal.ROUND_HALF_UP).stripTrailingZeros().toPlainString();
    }
}
