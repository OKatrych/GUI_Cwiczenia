/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad2;

import java.math.*;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Calc {
	private HashMap<String, Znak> map;

    public String doCalc(String arg){
        Znak znak1;
        String result = "";
        BigDecimal x;
        BigDecimal y;
        try {
            initList();
            x = new BigDecimal(arg.substring(0, arg.indexOf(" ")));
            y = new BigDecimal(arg.substring(arg.lastIndexOf(" ")+1, arg.length()));
            String znak = arg.replaceAll(x.toPlainString(),"");
            znak = znak.replaceAll(y.toPlainString(),"");
            znak = znak.replaceAll(" ","");
            znak1 = map.get(znak);
            result =  znak1.robic(x , y);
        }catch (Exception ex){
            return "Invalid command to calc";
        }
        return result;
    }

    private void initList(){
        map = new HashMap<>();
        map.put("+", new Plus());
        map.put("-", new Minus());
        map.put("/", new Divide());
        map.put("*", new Multiply());
    }
}  
