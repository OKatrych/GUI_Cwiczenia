package zad2;

import java.math.BigDecimal;

public class Minus extends Znak {
    @Override
    public String robic(BigDecimal x, BigDecimal y) {
        return x.subtract(y).toString();
    }
}
