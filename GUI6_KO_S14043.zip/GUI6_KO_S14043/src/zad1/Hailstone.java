package zad1;

import java.util.Iterator;

public class Hailstone implements Iterable<Integer>{

    private int a0;

    public Hailstone(int a0){
        if (a0 > 0)
            this.a0 = a0;
    }

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<Integer>() {
            @Override
            public boolean hasNext() {
                return a0 != 0;
            }
            @Override
            public Integer next() {
                if (a0 == 1){
                    a0 = 0;
                    return 1;
                }
                if (a0 % 2 == 0){
                    a0 /= 2;
                }else{
                    a0 = 1 + (3 * a0);
                }
                return a0;
            }
        };
    }
}
