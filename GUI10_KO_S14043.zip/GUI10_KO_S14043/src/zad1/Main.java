/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */
package zad1;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        new myFrame();
    }
}
    class myFrame extends JFrame {
        public myFrame(){
            setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            mTextArea text = new mTextArea(Color.BLUE, Color.YELLOW, new Font(Font.DIALOG, Font.ITALIC | Font.BOLD , 14));
            add(text.getPane());
            pack();
            setLocationRelativeTo(null);
            setVisible(true);
        }
    }
    class mTextArea{
        JTextArea textArea;
        public mTextArea(Color background, Color text, Font font){
            textArea = new JTextArea();
            textArea.setPreferredSize(new Dimension(500, 500));
            textArea.setBackground(background);
            textArea.setFont(font);
            textArea.setForeground(text);
        }
        public JScrollPane getPane(){
            return new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        }
    }

