/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad2;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        String key = JOptionPane.showInputDialog("Proszę podać literę z zakresu A-G");
        if (key.matches("[A-G]"))
            new mFrame(key);
        else {
            JOptionPane.showMessageDialog(new Frame(), "Błąd");
            System.exit(1);
        }
    }
}

class mFrame extends JFrame {
    mFrame(String key){
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        addComponentsToPane(getContentPane(), key);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void addComponentsToPane(Container pane, String key) {
        Button[] buttons = getButtons();
        switch (key){
            case "A" :   // BorderLayout
                pane.setLayout(new BorderLayout());
                pane.setComponentOrientation(
                        java.awt.ComponentOrientation.RIGHT_TO_LEFT);
                String[] aligment = {
                        BorderLayout.PAGE_START,
                        BorderLayout.CENTER,
                        BorderLayout.LINE_START,
                        BorderLayout.PAGE_END,
                        BorderLayout.LINE_END
                };
                for (int i = 0; i < buttons.length; i++) {
                    pane.add(buttons[i], aligment[i]);
                }
                break;
            case "B" :  // FlowLayout
                pane.setLayout(new FlowLayout());
                for (Button button : buttons) {
                    pane.add(button);
                }
                break;
            case "C" :  // FlowLayout(LEFT)
                pane.setLayout(new FlowLayout());
                for (Button button : buttons) {
                    pane.add(button);
                }
                pane.setComponentOrientation(
                        ComponentOrientation.RIGHT_TO_LEFT);
                break;
            case "D" :  // FlowLayout(RIGHT)
                pane.setLayout(new FlowLayout());
                for (Button button : buttons) {
                    pane.add(button);
                }
                pane.setComponentOrientation(
                        ComponentOrientation.LEFT_TO_RIGHT);
                break;
            case "E" :  // GridLayout(ROW);
                pane.setLayout(new GridLayout(1, buttons.length));
                for (Button button : buttons) {
                    pane.add(button);
                }
                break;
            case "F" :  // GridLayout(COLUMN);
                pane.setLayout(new GridLayout(buttons.length,1));
                for (Button button : buttons) {
                    pane.add(button);
                }
                break;
            case "G" :  // GridLayout(3, 2);
                pane.setLayout(new GridLayout(3,2));
                for (Button button : buttons) {
                    pane.add(button);
                }
                break;
        }
    }

    private Button[] getButtons(){
        String[] names = {"Przycisk 1", "P 2", "Większy przycisk numer 3", "Przycisk 4", "P5"};
        Button[] buttons = new Button[5];
        for (int i = 0; i < buttons.length; i++) {
            buttons[i] = new Button(names[i]);
        }
        return buttons;
    }
}