/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad1;

import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main {
  public static void main(String[] args) {
    new myFrame();
  }
}

class myFrame extends JFrame
{
  myFrame() {
    this.addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    myPanel pn = new myPanel();
    Container cont = getContentPane();
    cont.add(pn);
    setSize(600, 600);
    setVisible(true);
  }

}

class myPanel extends JPanel {
  public void paintComponent(Graphics gr) {
    gr.setColor(Color.BLUE);
    gr.drawLine(0, 0, getWidth(), getHeight());
    gr.drawLine(0, getHeight(), getWidth(), 0);
  }
}