/**
 *
 *  @author Katrych Oleksandr S14043
 *
 */

package zad2;


import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;

public class Main extends Application {

    private static String path;
    private static int time;
    private static String textSize;

    public static void main(String[] args) {
        try {
            path = args[0];
            time = Integer.parseInt(args[1]+"000");
            textSize = args[2];
        }catch (Exception ex){
            ex.printStackTrace();
        }
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        ImageView imageView = new ImageView();
        StackPane layout = new StackPane();
        Scene scene = new Scene(layout, 0, 0);
        HBox pictureBox = new HBox();
        Text text = new Text();
        text.setStyle("-fx-font: "+ textSize +" arial;");

        primaryStage.setTitle("ImageView");


        imageView.setPreserveRatio(true);
        imageView.setSmooth(true);
        imageView.setCache(true);
        // Image resizing by window
        imageView.fitWidthProperty().bind(scene.widthProperty());
        imageView.fitHeightProperty().bind(scene.heightProperty());

        pictureBox.getChildren().add(imageView);
        pictureBox.setAlignment(Pos.CENTER);

        layout.getChildren().add(pictureBox);
        layout.getChildren().add(text);
        layout.setAlignment(Pos.CENTER);

        primaryStage.setScene(scene);
        primaryStage.show();

        showContent(imageView, primaryStage, text);
    }

    private void showContent(ImageView imageView, Stage stage, Text text){

        final ArrayList<Image> images = getImages();

        Thread thread = new Thread(() -> {
            try {
                if (images.isEmpty()){
                    System.out.println("Image loading error");
                    text.setText("Brak obrazka");
                    return;
                }

                for (Image image : images){
                    stage.setWidth(image.getWidth());
                    stage.setHeight(image.getHeight());
                    imageView.setImage(image);
                    Thread.sleep(time);
                }
                imageView.setImage(null);
                text.setText("Koniec prezentacji");

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        thread.start();

    }

    /**
     *   Loading images from custom folder, with custom extensions
     *   @return Images array, or null (if file or folder not found)
     */
    private ArrayList<Image> getImages(){
        ArrayList<Image> images = new ArrayList<>();
        try {
            File directory = new File(path);
            final String[] EXTENSIONS = new String[]{"gif", "png", "jpg"};

            FilenameFilter filter = (File dir, String name) -> {
                for (String ext : EXTENSIONS) {
                    if (name.endsWith("." + ext)) {
                        return true;
                    }
                }
                return false;
            };

            for (File file : directory.listFiles(filter)) {
                try {
                    images.add(new Image(new FileInputStream(file)));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }catch (Exception ex){
            return images;
        }
        return images;
    }
}