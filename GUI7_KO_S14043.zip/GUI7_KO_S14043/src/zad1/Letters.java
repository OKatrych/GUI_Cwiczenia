package zad1;

public class Letters {

    private Thread[] threads;
    private String word;

    Letters(String word) {
        this.word = word;
        initThreadList();
    }

    Thread[] getThreads(){
        return threads;
    }

    private void initThreadList() {
        Runnable runnable = () -> {
                for (int i = 0; i < word.length(); i++) {
                    System.out.print(word.charAt(i));
                }
            while (Thread.interrupted()){}
        };
        threads = new Thread[word.length()];
        for (int i = 0; i < word.length(); i++) {
            threads[i] = new Thread(runnable);
            threads[i].setName("Thread " + word.charAt(i));
        }
    }
}
