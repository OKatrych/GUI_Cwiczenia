package zad2;

class StringTask implements Runnable{
    private Thread thread;
    private volatile TaskState state;
    private String text;
    private String result;
    private int count;

    StringTask(String text, int count){
        this.text = text;
        result = "";
        state = TaskState.CREATED;
        this.count = count;
        thread = new Thread(this);
    }

    @Override
    public void run() {
        for (int i = 0; i < count; i++) {
            if ((state == TaskState.ABORTED) || Thread.interrupted())
                return;
            result = result + text;
        }
        state = TaskState.READY;
    }

    void start(){
        thread.start();
        state = TaskState.RUNNING;
    }

    void abort(){
        state = TaskState.ABORTED;
        thread.interrupt();
    }

    boolean isDone(){
        return (state == TaskState.READY || state == TaskState.ABORTED);
    }

    TaskState getState(){
        return state;
    }

    String getResult(){
        return result;
    }
}
